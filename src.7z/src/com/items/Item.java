package com.items;

public interface Item {
    String getName();
}
