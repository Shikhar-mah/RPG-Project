package com.items;

import com.characters.Character;

public interface Usable {
    void use(Character target);
}
